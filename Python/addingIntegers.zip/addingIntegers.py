a = 25
b = 14
print(a + b)
